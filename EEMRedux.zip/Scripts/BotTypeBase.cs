﻿namespace EemRdx.Scripts
{
	public enum BotTypeBase
	{
		None,
		Invalid,
		Station,
		Fighter,
		Freighter,
		Carrier
	}
}