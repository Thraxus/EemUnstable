﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Timers;
using EemRdx.Scripts.Extensions;
using EemRdx.Scripts.Helpers;
using EemRdx.Scripts.ModCompatibility;
using EemRdx.Scripts.Models;
using Sandbox.Definitions;
using Sandbox.Game.Entities;
using Sandbox.Game.GUI.HudViewers;
using Sandbox.ModAPI;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.Entity;
using VRage.Game.ModAPI;
using VRage.Game.ModAPI.Ingame;
using VRage.Utils;
using VRageMath;
using IMyCubeGrid = VRage.Game.ModAPI.IMyCubeGrid;
using IMySlimBlock = VRage.Game.ModAPI.IMySlimBlock;

//using Cheetah.AI;

namespace EemRdx.Scripts
{
	[MySessionComponentDescriptor(MyUpdateOrder.BeforeSimulation)]
	public class AiSessionCore : MySessionComponentBase
	{
		private static readonly Dictionary<long, BotBase.OnDamageTaken> DamageHandlers = new Dictionary<long, BotBase.OnDamageTaken>();

		#region DictionaryAccessors
		public static void AddDamageHandler(long gridId, BotBase.OnDamageTaken handler)
		{
			DamageHandlers.Add(gridId, handler);
		}
		public static void AddDamageHandler(IMyCubeGrid grid, BotBase.OnDamageTaken handler)
		{
			AddDamageHandler(grid.GetTopMostParent().EntityId, handler);
		}
		public static void RemoveDamageHandler(long gridId)
		{
			DamageHandlers.Remove(gridId);
		}
		public static void RemoveDamageHandler(IMyCubeGrid grid)
		{
			RemoveDamageHandler(grid.GetTopMostParent().EntityId);
		}
		public static bool HasDamageHandler(long gridId)
		{
			return DamageHandlers.ContainsKey(gridId);
		}
		public static bool HasDamageHandler(IMyCubeGrid grid)
		{
			return HasDamageHandler(grid.GetTopMostParent().EntityId);
		}
		#endregion

		/// <summary>
		/// Tracks if the core initialization is complete or not
		/// </summary>
		private bool InitComplete { get; set; }

		private static List<FactionsAtWar> FactionsAtWar { get; } = new List<FactionsAtWar>();

		/// <summary>
		/// Struct to handle what's being tracked per Nanobot Build and Repair System entity
		/// </summary>
		private struct NanobotBuildAndRepair
		{
			public readonly long NanobotId;
			public readonly Vector3D ReportedLocation;
			public readonly long _reporterId;

			public NanobotBuildAndRepair(long nanobotId, Vector3D reportedLocation, long reporterId)
			{
				_reporterId = reporterId;
				NanobotId = nanobotId;
				ReportedLocation = reportedLocation;
			}
		}

		/// <summary>
		/// Holds the collection of Nanobot Build and Repair System entities being tracked
		/// </summary>
		private static List<NanobotBuildAndRepair> Nanobots { get; set; }

		/// <summary>
		/// Tracks how many ticks since last War Assessment
		/// </summary>
		private int _warAssessmentCounter;

		/// <summary>
		/// Tracks how many ticks since last Mod Assessment
		/// </summary>
		private int _modAssessmentCounter;

		/// <summary>
		/// 
		/// </summary>
		public static bool GameIsReady { get; private set; }

		/// <summary>
		/// 
		/// </summary>
		public override void UpdateBeforeSimulation()
		{
			if (!Constants.IsServer || !GameIsReady) return;						// If this isn't being processed on the server, or the game isn't ready, get out!
			if (_warAssessmentCounter >= Constants.WasAssessmentCounterLimit)		// Only assess faction war on the preset interval, skip otherwise to keep this as lightweight as possible
			{
				AssessFactionWar();
				_warAssessmentCounter = 0;
			}
			_warAssessmentCounter++;												// Increment this counter every game tick
			if (_modAssessmentCounter >= Constants.ModAssessmentCounter)            // Only assess faction war on the preset interval, skip otherwise to keep this as lightweight as possible
			{
				AssessMods();
				_modAssessmentCounter = 0;
			}
			_modAssessmentCounter++;                                                // Increment this counter every game tick
			
			if (InitComplete) return;                                               // We don't want to run anything after this point if the init routine is complete
			AiSeccionCoreInit();													// Initialize the core
		}

		/// <summary>
		/// General check to make sure the game is ready to begin processing code
		/// </summary>
		public override void BeforeStart()
		{
			GameIsReady = true;				
		}

		/// <summary>
		/// Core logic initialization
		/// </summary>
		private void AiSeccionCoreInit()
		{
			GrabModContent();
			if (Constants.NanobotBuildAndRepair) Nanobots = new List<NanobotBuildAndRepair>();
			SetupFactions();
			MyAPIGateway.Session.DamageSystem.RegisterBeforeDamageHandler(0, DamageRefHandler);
			MyAPIGateway.Session.DamageSystem.RegisterAfterDamageHandler(0, GenericDamageHandler);
			MyAPIGateway.Session.DamageSystem.RegisterDestroyHandler(0, GenericDamageHandler);
			InitComplete = true;
		}

		/// <summary>
		/// Assesses all mods being monitored by the core
		/// </summary>
		private static void AssessMods()
		{
			AssessNanobotLists();
		}

		/// <summary>
		/// This loops through the nanobot list to check on the status of all monitored tech
		/// </summary>
		private static void AssessNanobotLists()
		{
			if (!Constants.NanobotBuildAndRepair) return;

			for (int counter = Nanobots.Count - 1; counter >= 0; counter--)
			{ // Loop through the Nanobot struct backwards so we can RemoveAtFast and not affect the loop
				IMyShipWelder welder = MyAPIGateway.Entities.GetEntityById(Nanobots[counter].NanobotId) as IMyShipWelder;
				if (welder == null)
				{ // Block was destroyed
					ShowIngameMessage.ShowOverrideMessage("Forbidden tech no longer detected.  Standing down.");
					Nanobots.RemoveAtFast(counter);
					continue;
				}
				if (Vector3D.DistanceSquared(welder.GetPosition(), Nanobots[counter].ReportedLocation) > Constants.NanobotRangeToWatchSquared)
				{ // Block is outside of danger zone
					ShowIngameMessage.ShowOverrideMessage("Restricted area cleared.  High security standing down.  Reactivate your tech, if you dare.");
					Nanobots.RemoveAtFast(counter);
					continue;
				}
				if (!welder.Enabled) continue; // Block is still disabled - if enabled, code below executes
				ShowIngameMessage.ShowOverrideMessage("Treaty violation detected!  THIS MEANS WAR!!");
				DeclareFullAiWar(MyAPIGateway.Players.GetPlayerById(welder.OwnerId).GetFaction());
				Nanobots.RemoveAtFast(counter);
			}
		}


		/// <summary>
		/// Scans the Definition Manager for known Forbidden Tech definitions
		/// </summary>
		private static void GrabModContent()
		{
			DictionaryValuesReader<MyDefinitionId, MyDefinitionBase> definitionBase = MyDefinitionManager.Static.GetAllDefinitions();
			
			foreach (MyDefinitionBase definition in definitionBase)
			{

				if (Constants.EnergyShieldDefinitions.Any(definition.Id.SubtypeId.ToString().Contains))
					Constants.EnergyShields = true;

				if (Constants.DefenseShieldsModPackDefinitions.Any(definition.Id.SubtypeId.ToString().Contains))
					Constants.DefenseShieldsModPack = true;

				if (Constants.NanobotBuildAndRepairDefinitions.Any(definition.Id.SubtypeId.ToString().Contains))
					Constants.NanobotBuildAndRepair = true;
			}

			if(Constants.NanobotBuildAndRepair && Constants.Debug)
				ShowIngameMessage.ShowOverrideMessage("Nanobot Build and Repair System - Detected");

			if (Constants.EnergyShields && Constants.Debug)
				ShowIngameMessage.ShowOverrideMessage("Energy Shield - Detected");

			if (Constants.DefenseShieldsModPack && Constants.Debug)
				ShowIngameMessage.ShowOverrideMessage("Defense Shields - Mod Pack - Detected");
		}

		/// <summary>
		/// This accepts the items required to add a Nanobot Build and Repair System to the watch list.
		///		This mod has been considered "Forbidden Technology" in EEM and is subject to certain sanctions if used near an EEM entity
		/// </summary>
		/// <param name="watchMe">EntityID of the Nanobot Build and Repair System to monitor</param>
		/// <param name="fromHere">Origin point of the original scan to see if the forbidden tech is still within the danger zone </param>
		/// <param name="byThisEntity">EEM Prefab that did the original scan; captured for future planning</param>
		public static void AddNanobotToWatchList(List<long> watchMe, Vector3D fromHere, long byThisEntity)
		{
			if (watchMe.Count == 0) return;				// Initial detection can return a blank list, so exit if this is the case
			List<long> playerList = new List<long>();	// Holds a list of players to make sure we're not spamming warning messages for the same tech
			foreach (long welderId in watchMe)
			{ // loops through the welders that came in on the query to make sure we're accounting for all of the noticed forbidden tech
				IMyShipWelder welder = MyAPIGateway.Entities.GetEntityById(welderId) as IMyShipWelder;	// Cast the entityId as the known entity
				if (welder == null) continue;															// Welder may have been destroyed or deleted, need to make sure it's still there
				NanobotBuildAndRepair newNanobotCollection = new NanobotBuildAndRepair(welderId, fromHere, byThisEntity);			// Create the struct to be added to the list if it's a new item to watch
				int index = Nanobots.IndexOf(newNanobotCollection);										// Look to see if the struct is new or already exists
				if (index != -1)						
					continue;																			// -1 says the struct is new, so if not -1, then skip to the next entity
				Nanobots.Add(newNanobotCollection);														// This is a new item, add it to the list
				IMyPlayer player = MyAPIGateway.Players.GetPlayerById(welder.OwnerId);					// Find the entity owner and warn them of the violation
				if (player == null) continue;															// Player may be offline, someone else may be in their ship
				if (playerList.Contains(player.IdentityId)) continue;									// If the player has already been warned, skip to next entity
				playerList.Add(player.IdentityId);														// Log the player so we don't spam them with messages
				ShowIngameMessage.ShowOverrideMessage(
					$"{player.DisplayName}: You brought a Nanobot system within {Constants.NanobotRangeToWatch}m.  It has been deactivated.  Reactivating any Nanobot system while within range will violate the Galactic Fair War Convention 13473.86 subsection 42.");
			}
		}

		/// <summary>
		/// Initializes factions
		/// </summary>
		private static void SetupFactions()
		{
			if (!Factions.SetupComplete) Factions.Init();					// Catchall just in case this is called again for some unknown reason
			List<IMyPlayer> players = new List<IMyPlayer>();				// Create a player list
			MyAPIGateway.Multiplayer.Players.GetPlayers(players);			// Populate the player list
			foreach (IMyPlayer player in players)							// Iterate the list of players
			{
				IMyFaction playerFaction = player.GetFaction();				// Try to get the players faction
				if (playerFaction == null) continue;						// If the player isn't in a faction, skip and move on
				bool isAtWar = false;										// Quick check to see if the player is involved in a war already
				foreach (FactionsAtWar factionsAtWar in FactionsAtWar)		// Iterate the faction war list and make sure this player is clear
					if (factionsAtWar.PlayerFaction == playerFaction)		// Check to see if the player is in a war
						isAtWar = true;										// Player is in a war TODO: Implement war state saving so wars can be continued throughout saves and finish logic here
				if (!isAtWar) Factions.ProposePeaceToAllAi(playerFaction);	// if the player is free and clear, have all AI propose peace
			}
		}

		/// <summary>
		/// Assesses faction war status and declares peace as necessary
		/// </summary>
		private static void AssessFactionWar()
		{
			for (int counter = FactionsAtWar.Count - 1; counter >= 0; counter--)
				if ((FactionsAtWar[counter].CooldownTime -= Constants.WasAssessmentCounterLimit) <= 0)
				{
					Factions.ProposePeace(FactionsAtWar[counter].AiFaction, FactionsAtWar[counter].PlayerFaction);
					FactionsAtWar.RemoveAtFast(counter);
				}
		}

		/// <summary>
		/// Declares war against a player with the provided AI faction
		/// </summary>
		/// <param name="aiFaction">Computer controlled faction</param>
		/// <param name="playerFaction">Player controlled faction</param>
		public static void DeclareFactionWar(IMyFaction aiFaction, IMyFaction playerFaction)
		{
			FactionsAtWar war = new FactionsAtWar(aiFaction, playerFaction);
			int index = FactionsAtWar.IndexOf(war);
			if (index != -1)
				FactionsAtWar[index] = war;
			else
				FactionsAtWar.Add(war);
			if (Factions.IsLawful(aiFaction)) DeclareLawfulWar(playerFaction);
		}

		/// <summary>
		/// If the war is determined to be lawful (against a neutral faction), this includes the enforcement factions in the war
		/// </summary>
		/// <param name="playerFaction">Player controlled faction</param>
		private static void DeclareLawfulWar(IMyFaction playerFaction)
		{
			foreach (IMyFaction enforcementFaction in Factions.EnforcementFactions)
			{
				FactionsAtWar war = new FactionsAtWar(enforcementFaction, playerFaction);
				int index = FactionsAtWar.IndexOf(war);
				if (index != -1)
					FactionsAtWar[index] = war;
				else
					FactionsAtWar.Add(war);
			}
		}

		/// <summary>
		/// Used as a last resort - this declares war against the player from all neutral factions
		/// </summary>
		/// <param name="playerFaction">Player controlled faction</param>
		private static void DeclareFullAiWar(IMyFaction playerFaction)
		{
			foreach (IMyFaction enforcementFaction in Factions.LawfulFactions)
			{
				FactionsAtWar war = new FactionsAtWar(enforcementFaction, playerFaction);
				int index = FactionsAtWar.IndexOf(war);
				if (index != -1)
					FactionsAtWar[index] = war;
				else
					FactionsAtWar.Add(war);
			}
		}

		public void DamageRefHandler(object damagedObject, ref MyDamageInformation damage)
		{
			GenericDamageHandler(damagedObject, damage);
		}

		public void GenericDamageHandler(object damagedObject, MyDamageInformation damage)
		{  
			try
			{
				if (damage.AttackerId == 0 || !(damagedObject is IMySlimBlock)) return;
				IMySlimBlock damagedBlock = (IMySlimBlock)damagedObject;
				IMyCubeGrid damagedGrid = damagedBlock.CubeGrid;
				long gridId = damagedGrid.GetTopMostParent().EntityId;
				if (!DamageHandlers.ContainsKey(gridId)) return;
				try
				{
					DamageHandlers[gridId].Invoke(damagedBlock, damage);
				}
				catch (Exception scrap)
				{
					LogError("DamageHandler.Invoke", scrap);
				}
			}
			catch (Exception scrap)
			{
				LogError("GenericDamageHandler", scrap);
			}
		}

		public static void LogError(string source, Exception scrap, string debugPrefix = "SessionCore.")
		{
			MyLog.Default.WriteLine($"Core Crash - {scrap.StackTrace}");
			ShowIngameMessage.ShowSessionMessage($"Core Crash - Fatal error in '{debugPrefix + source}': {scrap.Message}. {(scrap.InnerException != null ? scrap.InnerException.Message : "No additional info was given by the game :(")}");
			DebugHelper.Print("Core Crash - Please reload the game", $"Fatal error in '{debugPrefix + source}': {scrap.Message}. {(scrap.InnerException != null ? scrap.InnerException.Message : "No additional info was given by the game :(")}");
		}

		public static void DebugWrite(string source, string message, bool antiSpam = true)
		{
			if (Constants.Debug) DebugHelper.Print($"{source}", $"{message}", antiSpam);
		}

	}
}