﻿using System;
using EemRdx.Scripts.Helpers;
using Sandbox.ModAPI;
using VRage.Game.ModAPI;

namespace EemRdx.Scripts
{
	public static class BotFabric
	{
		public static BotBase FabricateBot(IMyCubeGrid grid, IMyRemoteControl rc)
		{
			try
			{
				BotTypeBase botType = BotBase.ReadBotType(rc);

				BotBase bot = null;
				SwitchCase<BotTypeBase> switchType = new SwitchCase<BotTypeBase>(botType);
				switchType.Case(BotTypeBase.Fighter, () => bot = new BotTypeFighter(grid));
				switchType.Case(BotTypeBase.Freighter, () => bot = new BotTypeFreighter(grid));
				switchType.Case(BotTypeBase.Station, () => bot = new BotTypeStation(grid));
				switchType.Case(BotTypeBase.None, () => { });
				switchType.Case(BotTypeBase.Invalid, () => { });
				switchType.Case(BotTypeBase.Carrier, () => { });
				switchType.Default(() => { if (Constants.AllowThrowingErrors) throw new Exception("Invalid bot type"); });

				return bot;
			}
			catch (Exception scrap)
			{
				grid.LogError("BotFabric.FabricateBot", scrap);
				return null;
			}
		}
	}
}