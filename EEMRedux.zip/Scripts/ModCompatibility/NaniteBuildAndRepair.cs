﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EemRdx.Scripts.Helpers;
using Sandbox.Game.Definitions;
using Sandbox.Game.Entities;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Interfaces;
using VRage.Collections;
using VRage.Game.Entity;
using VRage.Game.ModAPI;
using VRage.Library.Utils;
using VRage.ModAPI;
using VRageMath;

namespace EemRdx.Scripts.ModCompatibility
{
	public static class NaniteBuildAndRepair
	{
		public static List<long> DetectNanobots(Vector3D detectionCenter, double range)
		{
			BoundingSphereD pruneSphere = new BoundingSphereD(detectionCenter, range);
			List<MyEntity> pruneList = new List<MyEntity>();
			List<long> welderList = new List<long>();
			MyGamePruningStructure.GetAllTopMostEntitiesInSphere(ref pruneSphere, pruneList, MyEntityQueryType.Dynamic);
			foreach (MyEntity ent in pruneList)
			{
				MyCubeGrid myGrid = ent as MyCubeGrid;
				if (myGrid == null) return welderList;
				foreach (MyCubeBlock block in myGrid.GetFatBlocks())
				{
					if (!(block is IMyShipWelder)) continue;
					if (!Constants.NanobotBuildAndRepairDefinitions.Any(x => block.BlockDefinition.BlockPairName.Contains(x))) continue;
					(block as IMyShipWelder).Enabled = false;
					(block as IMyShipWelder).Render.ColorMaskHsv = new Vector3(0, 0, 0.05f);
					welderList.Add((block as IMyShipWelder).EntityId);
				}
			}
			return welderList;
		}

		//public void DarkStarOne(Vector3D detectionCenter, double range)
		//{
		//	BoundingSphereD pruneSphere = new BoundingSphereD(detectionCenter, range);
		//	List<MyEntity> pruneList = new List<MyEntity>();

		//	MyGamePruningStructure.GetAllTopMostEntitiesInSphere(ref pruneSphere, pruneList, MyEntityQueryType.Dynamic);
		//	foreach (MyEntity ent in pruneList)
		//	{
		//		MyCubeGrid myGrid = ent as MyCubeGrid;
		//		if (myGrid == null) return;
		//		ListReader<MyCubeBlock> fatBlocks = myGrid.GetFatBlocks();
		//	}
		//}

		//public void DarkStarTwo(Vector3D detectionCenter, double range)
		//{
		//	BoundingSphereD pruneSphere = new BoundingSphereD(detectionCenter, range);
		//	List<MyEntity> pruneList = new List<MyEntity>();

		//	MyGamePruningStructure.GetAllTopMostEntitiesInSphere(ref pruneSphere, pruneList, MyEntityQueryType.Dynamic);
		//	foreach (MyEntity ent in pruneList)
		//	{
		//		if (ent.Physics != null || !ent.Render.Visible || !ent.DisplayName.Equals("dShield")) continue;
		//		IMyEntity parent = MyAPIGateway.Entities.GetEntityById(long.Parse(ent.Name));
		//		MyCubeBlock cubeBlock = (MyCubeBlock)parent;
		//		MyCubeGrid Grid = cubeBlock.CubeGrid;
		//		IMySlimBlock block = (IMySlimBlock)cubeBlock.SlimBlock;
		//	}
		//}
	}
}
