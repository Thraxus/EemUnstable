﻿using VRage.Game.ModAPI;
using VRageMath;

//using Cheetah.AI;

namespace EemRdx.Scripts.BotModules
{
    public abstract class BotModuleBase
    {
        public BotBase MyAI { get; private set; }
        protected IMyCubeGrid Grid => MyAI.Grid;
        protected Vector3D GridPosition => Grid.GetPosition();
        protected IMyFaction OwnerFaction => MyAI.OwnerFaction;

        public BotModuleBase(BotBase MyAI)
        {
            this.MyAI = MyAI;
        }

        public abstract void Close();
    }
}
