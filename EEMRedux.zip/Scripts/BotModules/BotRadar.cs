﻿using System;
using System.Collections.Generic;
using EemRdx.Scripts.Extensions;
using EemRdx.Scripts.Helpers;
using Sandbox.Game.Entities;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using VRage.Game.Entity;
using VRage.Game.ModAPI;
using VRage.ModAPI;
using VRageMath;

namespace EemRdx.Scripts.BotModules
{
    public class BotRadar : BotModuleBase
    {
        public List<MyDetectedEntityInfo> LookAround(float radius, Func<MyDetectedEntityInfo, bool> filter = null)
        {
            List<MyDetectedEntityInfo> radarData = new List<MyDetectedEntityInfo>();
            BoundingSphereD lookaroundSphere = new BoundingSphereD(GridPosition, radius);

            List<IMyEntity> entitiesAround = MyAPIGateway.Entities.GetTopMostEntitiesInSphere(ref lookaroundSphere);
            entitiesAround.RemoveAll(x => x == Grid || GridPosition.DistanceTo(x.GetPosition()) < Grid.WorldVolume.Radius * 1.5);

            long ownerId;
            if (OwnerFaction != null)
            {
                ownerId = OwnerFaction.FounderId;
                Grid.DebugWrite("LookAround", "Found owner via faction owner");
            }
            else
            {
                ownerId = MyAI.RC.OwnerId;
                Grid.DebugWrite("LookAround", "OWNER FACTION NOT FOUND, found owner via RC owner");
            }

            foreach (IMyEntity detectedEntity in entitiesAround)
            {
                if (detectedEntity is IMyFloatingObject || detectedEntity.Physics == null) continue;
                MyDetectedEntityInfo radarDetectedEntity = MyDetectedEntityInfoHelper.Create(detectedEntity as MyEntity, ownerId);
                if (radarDetectedEntity.Type == MyDetectedEntityType.None || radarDetectedEntity.Type == MyDetectedEntityType.Unknown) continue;
                if (filter == null || filter(radarDetectedEntity)) radarData.Add(radarDetectedEntity);
            }

            //DebugWrite("LookAround", $"Radar entities detected: {String.Join(" | ", RadarData.Select(x => $"{x.Name}"))}");
            return radarData;
        }

        public List<MyDetectedEntityInfo> LookForEnemies(float radius, bool considerNeutralsAsHostiles = false, Func<MyDetectedEntityInfo, bool> filter = null)
        {
            return !considerNeutralsAsHostiles ? LookAround(radius, x => x.IsHostile() && (filter == null || filter(x))) : LookAround(radius, x => x.IsNonFriendly() && (filter == null || filter(x)));
        }

        /// <summary>
        /// Returns distance from the grid to an object.
        /// </summary>
        public float Distance(MyDetectedEntityInfo target)
        {
            return (float)Vector3D.Distance(GridPosition, target.Position);
        }

        /// <summary>
        /// Returns distance from the grid to an object.
        /// </summary>
        //public float Distance(IMyEntity target)
        //{
        //	return (float)Vector3D.Distance(GridPosition, target.GetPosition());
        //}

        //public Vector3 RelVelocity(MyDetectedEntityInfo target)
        //{
        //	return target.Velocity - GridVelocity;
        //}

        public float RelSpeed(MyDetectedEntityInfo target)
        {
            return (target.Velocity - Grid.Physics.LinearVelocity).Length();
        }

        //public Vector3 RelVelocity(IMyEntity target)
        //{
        //	return target.Physics.LinearVelocity - GridVelocity;
        //}

        //public float RelSpeed(IMyEntity target)
        //{
        //	return (float)(target.Physics.LinearVelocity - GridVelocity).Length();
        //}

        public BotRadar(BotBase MyAI) : base(MyAI) { }

        public override void Close() { }
    }
}
