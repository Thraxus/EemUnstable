﻿using System;
using System.Collections.Generic;
using System.Linq;
using EemRdx.Scripts.BotModules;
using EemRdx.Scripts.Extensions;
using EemRdx.Scripts.Helpers;
using Sandbox.Game.Entities;
using Sandbox.ModAPI;
using Sandbox.ModAPI.Ingame;
using VRage.Game.Components;
using VRage.Game.Entity;
using VRage.Game.ModAPI;
using VRage.ModAPI;
using VRageMath;
//using Cheetah.AI;
using IMyGridTerminalSystem = Sandbox.ModAPI.IMyGridTerminalSystem;
using IMyProgrammableBlock = Sandbox.ModAPI.IMyProgrammableBlock;
using IMyRadioAntenna = Sandbox.ModAPI.IMyRadioAntenna;
using IMyRemoteControl = Sandbox.ModAPI.IMyRemoteControl;
using IMyTerminalBlock = Sandbox.ModAPI.IMyTerminalBlock;
using IMyThrust = Sandbox.ModAPI.IMyThrust;

namespace EemRdx.Scripts
{
	public abstract class BotBase
	{
		public IMyCubeGrid Grid { get; protected set; }

		protected readonly IMyGridTerminalSystem Term;

		public Vector3D GridPosition => Grid.GetPosition();

		public Vector3D GridVelocity => Grid.Physics.LinearVelocity;

		public float GridSpeed => (float)GridVelocity.Length();

		protected float GridRadius => (float)Grid.WorldVolume.Radius;

		protected TimeSpan CalmdownTime { get; set; } = (!Constants.Debug ? TimeSpan.FromMinutes(15) : TimeSpan.FromMinutes(3));

		protected bool Initialized
		{
			get
			{
				try
				{
					return Grid != null;
				}
				catch (Exception scrap)
				{
					LogError("initialized", scrap);
					return false;
				}
			}
		}

		public virtual bool IsInitialized => Initialized;

		public MyEntityUpdateEnum Update { get; protected set; }

		public IMyRemoteControl RC { get; protected set; }

        public IMyFaction OwnerFaction => _ownerFaction;
		private IMyFaction _ownerFaction;

		protected string DroneNameProvider => $"Drone_{RC.EntityId}";

		public string DroneName
		{
			get
			{
				return RC.Name;
			}
			protected set
			{
				IMyEntity entity = RC;
				entity.Name = value;
				MyAPIGateway.Entities.SetEntityName(entity);
			}
		}

		protected bool GridOperable
		{
			get
			{
				try
				{
					return !Grid.MarkedForClose && !Grid.Closed && Grid.InScene;
				}
				catch (Exception scrap)
				{
					LogError("gridoperable", scrap);
					return false;
				}
			}
		}

		protected bool BotOperable;

		protected bool Closed;

		public virtual bool Operable
		{
			get
			{
				try
				{
					return !Closed && IsInitialized && GridOperable && RC.IsFunctional && BotOperable;
				}
				catch (Exception scrap)
				{
					LogError("Operable", scrap);
					return false;
				}
			}
		}

        protected BotRadar MyRadar;

		public List<IMyRadioAntenna> Antennae { get; protected set; }

		public delegate void OnDamageTaken(IMySlimBlock damagedBlock, MyDamageInformation damage);

		protected event OnDamageTaken OnDamaged;

		public delegate void HOnBlockPlaced(IMySlimBlock block);

		protected event HOnBlockPlaced OnBlockPlaced;
		
		protected BotBase(IMyCubeGrid grid)
		{
			if (grid == null) return;
			Grid = grid;
			Term = grid.GetTerminalSystem();
			Antennae = new List<IMyRadioAntenna>();
		}

		public static BotTypeBase ReadBotType(IMyRemoteControl rc)
		{
			try
			{
				string customData = rc.CustomData.Trim().Replace("\r\n", "\n");
				List<string> myCustomData = new List<string>(customData.Split('\n'));

				if (customData.IsNullEmptyOrWhiteSpace()) return BotTypeBase.None;
				if (myCustomData.Count < 2)
				{
					if (Constants.AllowThrowingErrors) throw new Exception("CustomData is invalid", new Exception("CustomData consists of less than two lines"));
					return BotTypeBase.Invalid;
				}
				if (myCustomData[0].Trim() != "[EEM_AI]")
				{
					if (Constants.AllowThrowingErrors) throw new Exception("CustomData is invalid", new Exception($"AI tag invalid: '{myCustomData[0]}'"));
					return BotTypeBase.Invalid;
				}

				string[] BotTypeString = myCustomData[1].Split(':');
				if (BotTypeString[0].Trim() != "Type")
				{
					if (Constants.AllowThrowingErrors) throw new Exception("CustomData is invalid", new Exception($"Type tag invalid: '{BotTypeString[0]}'"));
					return BotTypeBase.Invalid;
				}

				BotTypeBase ParsedBotType = BotTypeBase.Invalid;

				SwitchCase<string> switchBotType = new SwitchCase<string>(BotTypeString[1].Trim());
				switchBotType.Case("Fighter", () => ParsedBotType = BotTypeBase.Fighter);
				switchBotType.Case("Freighter", () => ParsedBotType = BotTypeBase.Freighter);
				switchBotType.Case("Carrier", () => ParsedBotType = BotTypeBase.Carrier);
				switchBotType.Case("Station", () => ParsedBotType = BotTypeBase.Station);

				return ParsedBotType;
			}
			catch (Exception scrap)
			{
				rc.CubeGrid.LogError("[STATIC]BotBase.ReadBotType", scrap);
				return BotTypeBase.Invalid;
			}
		}

		protected virtual void DebugWrite(string source, string message, string debugPrefix = "BotBase.")
		{
			Grid.DebugWrite(debugPrefix + source, message);
		}

		public virtual bool Init(IMyRemoteControl rc = null)
		{
			RC = rc ?? Term.GetBlocksOfType<IMyRemoteControl>(collect: x => x.IsFunctional).FirstOrDefault();
			if (rc == null) return false;
			DroneName = DroneNameProvider;

			Antennae = Term.GetBlocksOfType<IMyRadioAntenna>(collect: x => x.IsFunctional);

			bool hasSetup = ParseSetup();
			if (!hasSetup) return false;

			AiSessionCore.AddDamageHandler(Grid, (block, damage) => { OnDamaged?.Invoke(block, damage); });

			Grid.OnBlockAdded += block => { OnBlockPlaced?.Invoke(block); };

			_ownerFaction = Grid.GetOwnerFaction(true);

            MyRadar = new BotRadar(this);

			BotOperable = true;

			return true;
		}

		protected virtual void ReactOnDamage(IMySlimBlock block, MyDamageInformation damage, TimeSpan truceDelay, out IMyPlayer damager)
		{
			damager = null;
			try
			{
				// Inconsequential damage sources, ignore them
				if (damage.IsDeformation || damage.IsMeteor() || damage.IsThruster())
					return;

				try
				{
					if (damage.IsDoneByPlayer(out damager) && damager != null)
					{
						try
						{
							if (damager.GetFaction() == null) return;
							DeclareWar(damager.GetFaction());
						}
						catch (Exception scrap)
						{
							Grid.LogError("ReactOnDamage.GetDamagerFaction", scrap);
						}
					}
					else Grid.DebugWrite("ReactOnDamage", "Grid is damaged, but damage source is not recognized as player.");
				}
				catch (Exception scrap)
				{
					Grid.LogError("ReactOnDamage.IsDamageDoneByPlayer", scrap);
				}
			}
			catch (Exception scrap)
			{
				Grid.LogError("ReactOnDamage", scrap);
			}
		}

		protected virtual void BlockPlacedHandler(IMySlimBlock block)
		{
			if (block == null) return;

			try
			{
				IMyPlayer builder;
				if (!block.IsPlayerBlock(out builder)) return;
				IMyFaction faction = builder.GetFaction();
				if (faction != null)
					DeclareWar(faction);
				//{
				//	RegisterHostileAction(faction, CalmdownTime);
				//}
			}
			catch (Exception scrap)
			{
				Grid.LogError("BlokPlaedHandler", scrap);
			}
		}

		protected virtual void DeclareWar(IMyFaction playerFaction)
		{
			if (_ownerFaction == null)
				_ownerFaction = Grid.GetOwnerFaction();
			AiSessionCore.DeclareFactionWar(_ownerFaction, playerFaction);
		}

		protected bool HasModdedThrusters => SpeedmoddedThrusters.Count > 0;
		protected List<IMyThrust> SpeedmoddedThrusters = new List<IMyThrust>();

		protected void ApplyThrustMultiplier(float thrustMultiplier)
		{
			DemultiplyThrusters();
			foreach (IMyThrust thruster in Term.GetBlocksOfType<IMyThrust>(collect: x => x.IsOwnedByNpc(allowNobody: false, checkBuilder: true)))
			{
				thruster.ThrustMultiplier = thrustMultiplier;
				thruster.OwnershipChanged += Thruster_OnOwnerChanged;
				SpeedmoddedThrusters.Add(thruster);
			}
		}

		protected void DemultiplyThrusters()
		{
			if (!HasModdedThrusters) return;
			foreach (IMyThrust thruster in SpeedmoddedThrusters)
			{
				if (Math.Abs(thruster.ThrustMultiplier - 1) > 0) thruster.ThrustMultiplier = 1;
			}
			SpeedmoddedThrusters.Clear();
		}

		private void Thruster_OnOwnerChanged(IMyTerminalBlock thruster)
		{
			try
			{
				IMyThrust myThruster = thruster as IMyThrust;
				if (myThruster == null) return;
				if (!myThruster.IsOwnedByNpc() && Math.Abs(myThruster.ThrustMultiplier - 1) > 0) myThruster.ThrustMultiplier = 1;
			}
			catch (Exception scrap)
			{
				Grid.DebugWrite("Thruster_OnOwnerChanged", $"{thruster.CustomName} OnOwnerChanged failed: {scrap.Message}");
			}
		}

		protected abstract bool ParseSetup();

		public abstract void Main();

		public virtual void Shutdown()
		{
			Closed = true;

            MyRadar.Close();

			if (HasModdedThrusters) DemultiplyThrusters();
			AiSessionCore.RemoveDamageHandler(Grid);
		}

		public void LogError(string source, Exception scrap, string debugPrefix = "BotBase.")
		{
			Grid.LogError(debugPrefix + source, scrap);
		}
	}
}