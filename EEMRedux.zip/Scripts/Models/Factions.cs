﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EemRdx.Scripts.Extensions;
using EemRdx.Scripts.Helpers;
using Sandbox.Definitions;
using Sandbox.ModAPI;
using VRage.Game;
using VRage.Game.ModAPI;

namespace EemRdx.Scripts.Models
{
	public static class Factions
	{
		public static bool SetupComplete;

		public static List<IMyFaction> LawfulFactions { get; private set; }

		public static List<IMyFaction> EnforcementFactions { get; private set; }

		/// <summary>
		/// These factions are considered lawful. When they go hostile towards someone,
		/// they also make the police (SEPD) and army (UCMF) go hostile.
		/// </summary>
		public static List<string> LawfulFactionsTags { get; } = new List<string>
		{
			"UCMF",
			"SEPD",
			"CIVL",
			"ISTG",
			"MA-I",
			"EXMC",
			"KUSS",
			"HS",
			"AMPH",
			"IMDC",
		};

		public static List<string> AllNpcFactions { get; } = new List<string>
		{
			"SPRT",
			"CIVL",
			"UCMF",
			"SEPD",
			"ISTG",
			"AMPH",
			"KUSS",
			"HS",
			"MMEC",
			"MA-I",
			"EXMC",
			"IMDC"
		};

		public static List<string> EnforcementFactionsTags { get; } = new List<string>
		{
			"SEPD","UCMF"
		};

		public static bool IsLawful(IMyFaction checkFaction)
		{
			return LawfulFactions.Contains(checkFaction);
		}

		public static void ProposePeaceToAllAi(IMyFaction playerFaction)
		{
			foreach (IMyFaction faction in LawfulFactions)
				if(!IsPeaceful(playerFaction, faction)) MyAPIGateway.Session.Factions.SendPeaceRequest(faction.FactionId, playerFaction.FactionId);
		}

		public static void ProposePeace(IMyFaction leftFaction, IMyFaction rightFaction)
		{
			MyAPIGateway.Session.Factions.SendPeaceRequest(leftFaction.FactionId, rightFaction.FactionId);
		}

		public static void AcceptPeace(IMyFaction leftFaction, IMyFaction rightFaction)
		{
			MyAPIGateway.Session.Factions.AcceptPeace(leftFaction.FactionId, rightFaction.FactionId);
		}

		public static bool IsPeaceful(IMyFaction leftFaction, IMyFaction rightFaction)
		{
			return MyAPIGateway.Session.Factions.GetRelationBetweenFactions(leftFaction.FactionId, rightFaction.FactionId) != MyRelationsBetweenFactions.Enemies;
		}

		public static void Init()
		{
			EnforcementFactions = MyAPIGateway.Session.Factions.Factions.Values.Where(x => EnforcementFactionsTags.Contains(x.Tag)).ToList();
			LawfulFactions = MyAPIGateway.Session.Factions.Factions.Values.Where(x => LawfulFactionsTags.Contains(x.Tag)).ToList();
			NpcFactionPeace();
			SetupNpcFaction();
			SetupComplete = true;
		}

		private static void SetupNpcFaction()
		{
			foreach (MyFactionDefinition faction in MyDefinitionManager.Static.GetDefaultFactions())
			{
				faction.AcceptHumans = false;
				faction.AutoAcceptMember = false;
			}
		}

		private static void NpcFactionPeace()
		{
			foreach (IMyFaction leftFaction in LawfulFactions)
			{
				foreach (IMyFaction rightFaction in LawfulFactions)
					if (leftFaction != rightFaction)
						if (!IsPeaceful(leftFaction, rightFaction))
						{
							ProposePeace(leftFaction, rightFaction);
							AcceptPeace(rightFaction, leftFaction);
						}
			}
		}
	}
}
