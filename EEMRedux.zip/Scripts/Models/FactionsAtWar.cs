﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EemRdx.Scripts.Helpers;
using Sandbox.Game.World;
using Sandbox.ModAPI;
using VRage.Entities.Components;
using VRage.Game.ModAPI;

namespace EemRdx.Scripts.Models
{
	public class FactionsAtWar : IEquatable<FactionsAtWar>
	{
		public IMyFaction AiFaction { get; }

		public IMyFaction PlayerFaction { get; }

		public int CooldownTime { get; set; }

		public FactionsAtWar(IMyFaction aiFaction, IMyFaction playerFaction)
		{
			MyAPIGateway.Session.Factions.DeclareWar(aiFaction.FactionId, playerFaction.FactionId);
			AiFaction = aiFaction;
			PlayerFaction = playerFaction;
			CooldownTime = Constants.FactionCooldown;
		}

		public void UpdateTimer(FactionsAtWar replacementWar)
		{
			CooldownTime = replacementWar.CooldownTime;
		}

		public override bool Equals(object obj)
		{
			return Equals(obj as FactionsAtWar);
		}

		public override int GetHashCode()
		{
			unchecked
			{
				return ((AiFaction != null ? AiFaction.GetHashCode() : 0) * 397) ^ (PlayerFaction != null ? PlayerFaction.GetHashCode() : 0);
			}
		}

		public bool Equals(FactionsAtWar other)
		{
			return other != null &&
				   EqualityComparer<IMyFaction>.Default.Equals(AiFaction, other.AiFaction) &&
				   EqualityComparer<IMyFaction>.Default.Equals(PlayerFaction, other.PlayerFaction);
		}
	}
}
