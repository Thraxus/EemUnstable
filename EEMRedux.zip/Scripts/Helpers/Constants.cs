using System.Collections.Generic;
using Sandbox.ModAPI;

// ReSharper disable StringLiteralTypo

namespace EemRdx.Scripts.Helpers
{
	public static class Constants
	{
		#region "General Settings"

		/// <summary>
		/// General Debug Mode for the mod
		/// </summary>
		public static bool Debug { get; set; } = false;

		/// <summary>
		/// This permits certain operations to throw custom exceptions in order to
		/// provide detailed descriptions of what gone wrong, over call stack.<para />
		/// BEWARE, every exception thrown must be explicitly provided with a catcher, or it will crash the entire game!
		/// </summary>
		public static bool AllowThrowingErrors { get; set; } = true;

		/// <summary>
		/// Easy reference for how many ticks are in 1 second
		/// </summary>
		private const int TicksPerSecond = 60;

		/// <summary>
		/// Returns if the code is executing on the server or locally
		/// </summary>
		public static bool IsServer => MyAPIGateway.Multiplayer.IsServer;

		#endregion

		#region "Mod Detected Switches"

		// General Mod Detection settings

		/// <summary>
		/// How often we want to scan to see the status of the EntityId reported.
		///		This is in ticks.  1 tick = 1/60 second
		/// </summary>
		public static int ModAssessmentCounter { get; } = 100;

		#region "Forbidden Tech: Nanobot Build and Repair System - https://steamcommunity.com/sharedfiles/filedetails/?id=857053359"

		/// <summary>
		/// If this is set to true, the Nanobot Build and Repair System has been detected as an active mod
		/// </summary>
		public static bool NanobotBuildAndRepair { get; set; }

		/// <summary>
		/// List of all known DefinitionIds for the Nanobot Build and Repair System
		/// </summary>
		public static List<string> NanobotBuildAndRepairDefinitions { get; } = new List<string>()
		{
			"SELtdNanobotBuildAndRepairSystem",
			"SELtdLargeNanobotBuildAndRepairSystem",
			"SELtdSmallNanobotBuildAndRepairSystem"
		};

		/// <summary>
		/// Range we want to keep the Nanobot Build and Repair System suppressed for
		/// </summary>
		public static double NanobotRangeToWatch { get; } = 300;

		/// <summary>
		/// Squared of the RangeToWatch, used for calculations to see if the forbidden tech is still within the danger zone
		/// </summary>
		public static double NanobotRangeToWatchSquared { get; } = NanobotRangeToWatch * NanobotRangeToWatch;

		#endregion


		#region "Forbidden Tech: Energy Shields - https://steamcommunity.com/sharedfiles/filedetails/?id=484504816"

		/// <summary>
		/// 
		/// </summary>
		public static bool EnergyShields { get; set; }

		/// <summary>
		/// List of all known DefinitionIds for the Nanobot Build and Repair System
		/// </summary>
		public static List<string> EnergyShieldDefinitions { get; } = new List<string>()
		{
			"LargeShipSmallShieldGeneratorBase",
			"LargeShipLargeShieldGeneratorBase",
			"SmallShipSmallShieldGeneratorBase",
			"SmallShipMicroShieldGeneratorBase"
		};

		#endregion

		#region "Forbidden Tech: Defense Shields - Mod Pack - https://steamcommunity.com/sharedfiles/filedetails/?id=1365616918"

		/// <summary>
		/// 
		/// </summary>
		public static bool DefenseShieldsModPack { get; set; }

		public static List<string> DefenseShieldsModPackDefinitions { get; } = new List<string>()
		{
			"DefenseShieldsLS",
			"DefenseShieldsSS",
			"DefenseShieldsST"
		};

		#endregion

		#endregion

		#region "Factions"

		/// <summary>
		/// Faction War cooldown period
		///		15 minute default cooldown, 2 minute in Debug Mode
		/// </summary>
		public static int FactionCooldown => Debug? (TicksPerSecond * 60 * 15) : (TicksPerSecond * 60 * 2); 


		/// <summary>
		/// How often we assess the current wars to see if the cooldown period has elapsed
		/// </summary>
		public const int WasAssessmentCounterLimit = 60;

		#endregion


		// used in both CleanUp.cs and BuyShip.cs
		public static HashSet<string> NpcFactions { get; } = new HashSet<string>()
		{
			"SPRT",
			"CIVL",
			"UCMF",
			"SEPD",
			"ISTG",
			"AMPH",
			"KUSS",
			"HS",
			"MA-I",
			"EXMC",
			"IMDC"
		};

		// CleanUp.cs's constants:

		// verbose debug log output
		public static bool CleanupDebug { get; } = false;

		// text required in the RC's CustomData to be even considered for removal
		public static string CleanupRcTag { get; } = "[EEM_AI]";

		// any of these is required to be in RC's CustomData for the grid to be removed.
		public static string[] CleanupRcExtraTags { get; } = { "Type:Fighter", "Type:Freighter" };

		// clamp the world's view range to this minimum value, which is used for removing distant ships
		public static int CleanupMinRange { get; } = 25000;

		// remove connector-connected ships too?
		public static bool CleanupConnectorConnected { get; } = false;

		// world setting of max drones
		public static int ForceMaxDrones { get; } = 20;
		
		// BuyShip.cs's constants:

		// time in seconds to wait after spawning before spawning again
		public static int TradeDelaySeconds { get; } = 15;

		// prefix and suffix words that encapsulate the prefab name
		public static string TradeEchoPrefix { get; } = "Ship bought:";

		public static string TradeEchoSuffix { get; } = "\n";

		// relative spawn position to the PB, use negative for the opposite direction
		public static double SpawnRelativeOffsetUp { get; } = 10.0;

		public static double SpawnRelativeOffsetLeft { get; } = 0.0;

		public static double SpawnRelativeOffsetForward { get; } = 0.0;

		// after the ship is spawned, all blocks with inventory in the PB's grid with this word in their name and owned by the trader faction will have their contents purged
		public static string PostspawnEmptyinventoryTag { get; } = "(purge)";

		// the particle effect name (particles.sbc) to spawn after the ship is spawned
		public static string SpawnEffectName { get; } = "EEMWarpIn";

		// the ship's bounding sphere radius is used for the particle effect scale, this value scales that radius.
		public static float SpawnEffectScale { get; } = 0.2f;

		// radius of the area around the spawn zone to check for foreign objects
		public static float SpawnAreaRadius { get; } = 15f;

		// the argument that gets used by the mod to call the PB when the buy ship fails due to the position being blocked
		public static string PbargFailPositionblocked { get; } = "fail-positionblocked";

		// in case the PB doesn't work, notify the players within this radius of the failed spawn ship
		public static float SpawnFailNotifyDistance { get; } = 50;
	}
}