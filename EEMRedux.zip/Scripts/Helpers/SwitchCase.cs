﻿using System;

namespace EemRdx.Scripts
{
    public sealed class SwitchCase<T>
    {
        private readonly T _value;
        private bool _hasMatch = false;
        public SwitchCase(T switchValue)
        {
            _value = switchValue;
        }

        public void Case(T checkValue, Action func)
        {
            if (_value.Equals(checkValue))
            {
                _hasMatch = true;
                func();
            }
        }

        public void Default(Action func)
        {
            if (!_hasMatch) func();
        }
    }
}
